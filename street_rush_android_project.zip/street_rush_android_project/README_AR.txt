STREET RUSH 3D — مشروع Android لتجهيز APK

هذا مجلد مشروع Android Studio، وليس ملف APK جاهزًا. تم تضمين ملفات اللعبة داخل assets، ويحمّل محرك Three.js من الإنترنت، لذلك يلزم اتصال بالإنترنت أثناء اللعب.

طريقة إنشاء APK:
1) ثبّت Android Studio على كمبيوتر.
2) فك ضغط street_rush_android_project.zip.
3) من Android Studio اختر Open وافتح مجلد street_rush_android_project.
4) انتظر Gradle Sync وتثبيت Android SDK Platform 35 إذا طُلب ذلك.
5) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
6) بعد نجاح البناء، ستجد الملف غالبًا في app/build/outputs/apk/debug/app-debug.apk.
7) انقل APK إلى هاتف Android وافتحه للتثبيت. قد تحتاج السماح بالتثبيت من هذا المصدر.

ملاحظات:
- يحتاج المشروع إلى اتصال إنترنت لتنزيل إضافات Gradle وAndroid SDK عند البناء، ولتحميل مكتبة Three.js أثناء تشغيل اللعبة.
- إعدادات المشروع: Android Studio / Gradle، Android 6.0 (API 23) أو أحدث.
- هذا مشروع أولي مغلّف داخل WebView، وليس لعبة أصلية بمحرك Unity أو Unreal. الأداء الرسومي يعتمد على الهاتف.
